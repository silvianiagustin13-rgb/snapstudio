<?php

/**
 * E012_pdfx3.php
 */

require __DIR__ . '/../vendor/autoload.php';

\define('K_PATH_FONTS', \realpath(__DIR__ . '/../vendor/tecnickcom/tc-lib-pdf-font/target/fonts'));

$pdf = new \Com\Tecnick\Pdf\Tcpdf(unit: 'mm', isunicode: true, subsetfont: false, compress: true, mode: 'pdfx3');

$pdf->setCreator('tc-lib-pdf');
$pdf->setAuthor('Nicola Asuni');
$pdf->setSubject('tc-lib-pdf example: 012');
$pdf->setTitle('PDF/X-3 Example');
$pdf->setKeywords('TCPDF tc-lib-pdf example pdfx3');
$pdf->setPDFFilename('012_pdfx3.pdf');

$font = $pdf->font->insert($pdf->pon, 'helvetica', '', 12);
$pdf->addPage();
$pdf->page->addContent($font['out']);

$html =
    '<h1>PDF/X-3</h1>'
    . '<p>Mode: pdfx3</p>'
    . '<p>PDF/X-3 keeps the print-exchange restrictions of early PDF/X while allowing '
    . 'color-managed workflows beyond device CMYK.</p>'
    . '<p>Highlights: minimum PDF 1.3 output, output-intent identification, no transparency, '
    . 'and no interactive actions that would conflict with print-only delivery.</p>';

$pdf->addHTMLCell(html: $html, posx: 15, posy: 20, width: 180);

$rawpdf = $pdf->getOutPDFString();
$pdf->renderPDF(rawpdf: $rawpdf);
